import { neon } from '@neondatabase/serverless';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('Missing DATABASE_URL. Copy .env.example to .env.local and fill it in.');
  process.exit(1);
}

const sql = neon(DATABASE_URL);
const schema = readFileSync(join(__dirname, 'schema.sql'), 'utf-8');

console.log('Deploying Nexus schema to Neon...');

try {
  await sql(schema);
  console.log('✓ Schema deployed successfully.');

  // Verify
  const tables = await sql`
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    ORDER BY table_name
  `;
  console.log('  Tables:', tables.map(t => t.table_name).join(', '));
} catch (err) {
  console.error('✗ Deploy failed:', err.message);
  process.exit(1);
}
