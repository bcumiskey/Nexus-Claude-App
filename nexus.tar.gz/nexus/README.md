# Nexus

A self-hosted AI operations platform. Persistent chat with project context injection, prompt enhancement, and config-driven model management.

## What It Does

1. **Persistent Chat** — Talk to Claude through your own interface. Conversations saved to Postgres. SSE streaming. Model selection with extended thinking and fast mode toggles.

2. **Project Context** — Create projects (anything — a codebase, a business, a side project). Attach context: decisions, discoveries, constraints. That context automatically injects into the system prompt when you chat within that project.

3. **Prompt Enhancement** — Toggle Enhanced mode. Your prompt goes to Haiku first for optimization, then you review the enhanced version before sending. Accept, edit, send original, or cancel.

4. **Config-Driven Models** — Models, pricing, and capabilities live in the database. When Anthropic ships a new model, add a row. No code change, no redeploy.

## Stack

- **Next.js 16** (App Router)
- **Neon** (Serverless Postgres)
- **Anthropic SDK** (Claude API)
- **Vercel** (Deployment)
- **Tailwind CSS 4**
- **Renovate** (Automated dependency updates)

## Setup

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USER/nexus.git
cd nexus
npm install
```

### 2. Environment

```bash
cp .env.example .env.local
```

Edit `.env.local` with your Neon connection string and Anthropic API key.

### 3. Deploy schema

Paste `db/schema.sql` into the Neon SQL editor, or:

```bash
npx dotenv -e .env.local node db/deploy.mjs
```

This creates the tables and seeds the current Claude models with pricing.

### 4. Run locally

```bash
npm run dev
```

### 5. Deploy to Vercel

```bash
vercel
```

Set `DATABASE_URL` and `ANTHROPIC_API_KEY` in Vercel dashboard.

## Adding New Models

When Anthropic releases a new model, no code change is needed. Run this SQL in the Neon console:

```sql
-- Example: adding a hypothetical Claude Sonnet 5
INSERT INTO models (id, label, tier, input_price, output_price, max_output, context_window,
    supports_thinking, supports_adaptive, supports_fast, supports_1m_ctx,
    is_default, sort_order, notes)
VALUES (
    'claude-sonnet-5-20260601', 'Sonnet 5', 'standard', 3.00, 15.00, 64000, 200000,
    TRUE, TRUE, FALSE, TRUE,
    FALSE, 2, 'Next-gen Sonnet.'
);

-- To make it the default:
UPDATE models SET is_default = FALSE WHERE is_default = TRUE;
UPDATE models SET is_default = TRUE WHERE id = 'claude-sonnet-5-20260601';

-- To retire an old model:
UPDATE models SET is_active = FALSE WHERE id = 'claude-sonnet-4-5-20250929';
```

The frontend fetches available models from `/api/models` on load. Changes appear immediately.

## Updating Pricing

```sql
UPDATE models SET input_price = 2.00, output_price = 10.00, updated_at = NOW()
WHERE id = 'claude-sonnet-4-6';
```

Cost calculations use the database values, not hardcoded constants.

## API Routes

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Connectivity check (DB + API + model count) |
| GET | `/api/models` | List active models with capabilities |
| PUT | `/api/models` | Add or update a model (upsert) |
| GET | `/api/chat` | List chats |
| POST | `/api/chat` | Create chat |
| GET | `/api/chat/[id]` | Chat + messages |
| PATCH | `/api/chat/[id]` | Update chat |
| DELETE | `/api/chat/[id]` | Delete chat |
| POST | `/api/chat/[id]/send` | Send message (SSE stream) |
| POST | `/api/enhance` | Enhance prompt |
| GET | `/api/project` | List projects |
| POST | `/api/project` | Create project |
| GET | `/api/project/[id]` | Project + context |
| PATCH | `/api/project/[id]` | Update project/context |
| DELETE | `/api/project/[id]` | Delete project |

## Schema

7 tables: `models`, `settings`, `projects`, `project_context`, `chats`, `messages`, `enhancements`. See `db/schema.sql`.

## Dependency Management

Renovate is configured (`renovate.json`) to open PRs for dependency updates weekly. Anthropic SDK patches auto-merge. Next.js and Neon updates require review. Enable the Renovate GitHub App on the repo.

## Adapting to Change

| What changes | How to adapt | Effort |
|---|---|---|
| New model | Add row to `models` table | SQL, no deploy |
| Pricing change | Update `models` row | SQL, no deploy |
| Retire a model | Set `is_active = false` | SQL, no deploy |
| SDK update | Renovate PR → review → merge → auto-deploy | ~5 min |
| New API capability | Add DB column + UI toggle + SDK param | Small code change |
| Next.js major | Renovate PR → test → merge | ~30 min |
