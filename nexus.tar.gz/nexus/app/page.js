'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// ── API helpers ──

async function api(path, opts = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json', ...opts.headers },
    ...opts,
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.statusText);
  return res.json();
}

function streamSend(chatId, content, modelId, enhanced, thinking, fast, onDelta, onThinking, onDone, onError) {
  const ctrl = new AbortController();
  fetch(`/api/chat/${chatId}/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content, model_id: modelId, enhanced, thinking, fast }),
    signal: ctrl.signal,
  }).then(async (res) => {
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop() || '';
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        try {
          const d = JSON.parse(line.slice(6));
          if (d.type === 'delta') onDelta(d.text);
          else if (d.type === 'thinking') onThinking?.(d.text);
          else if (d.type === 'thinking_start') onThinking?.('[thinking]\n');
          else if (d.type === 'done') onDone?.(d.usage);
          else if (d.type === 'error') onError?.(d.error);
        } catch {}
      }
    }
  }).catch(e => { if (e.name !== 'AbortError') onError?.(e.message); });
  return () => ctrl.abort();
}

// ── Main App ──

export default function Nexus() {
  // Models from API
  const [models, setModels] = useState([]);
  const [model, setModel] = useState('');

  const [chats, setChats] = useState([]);
  const [projects, setProjects] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [streamText, setStreamText] = useState('');
  const [thinkingText, setThinkingText] = useState('');
  const [enhanceMode, setEnhanceMode] = useState(false);
  const [thinkingMode, setThinkingMode] = useState(false);
  const [fastMode, setFastMode] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [enhancement, setEnhancement] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [health, setHealth] = useState(null);
  const [sidebarTab, setSidebarTab] = useState('chats');
  const messagesEnd = useRef(null);
  const inputRef = useRef(null);

  // Derived: current model capabilities
  const currentModel = models.find(m => m.id === model);

  // Load models, chats, projects, health on mount
  useEffect(() => {
    api('/models').then(m => {
      setModels(m);
      const def = m.find(x => x.is_default) || m[0];
      if (def) setModel(def.id);
    }).catch(console.error);
    api('/chat').then(setChats).catch(console.error);
    api('/project').then(setProjects).catch(console.error);
    api('/health').then(setHealth).catch(() => setHealth({ status: 'unreachable' }));
  }, []);

  // Scroll to bottom
  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamText]);

  // Load messages when active chat changes
  useEffect(() => {
    if (!activeChat) { setMessages([]); return; }
    api(`/chat/${activeChat.id}`).then(data => {
      setMessages(data.messages);
      setModel(data.chat.model_id);
      setSelectedProject(data.chat.project_id);
    }).catch(console.error);
  }, [activeChat?.id]);

  // Reset toggles when model changes
  useEffect(() => {
    if (currentModel) {
      if (!currentModel.supports_thinking) setThinkingMode(false);
      if (!currentModel.supports_fast) setFastMode(false);
    }
  }, [model]);

  const createChat = async () => {
    const chat = await api('/chat', {
      method: 'POST',
      body: JSON.stringify({ model_id: model, project_id: selectedProject }),
    });
    setChats(prev => [chat, ...prev]);
    setActiveChat(chat);
    setMessages([]);
    inputRef.current?.focus();
  };

  const selectChat = (chat) => {
    if (streaming) return;
    setActiveChat(chat);
    setEnhancement(null);
  };

  const deleteChat = async (e, chatId) => {
    e.stopPropagation();
    await api(`/chat/${chatId}`, { method: 'DELETE' });
    setChats(prev => prev.filter(c => c.id !== chatId));
    if (activeChat?.id === chatId) {
      setActiveChat(null);
      setMessages([]);
    }
  };

  const send = useCallback(async (text, enhanced = false) => {
    if (!text.trim() || streaming) return;

    let chatId = activeChat?.id;
    if (!chatId) {
      const chat = await api('/chat', {
        method: 'POST',
        body: JSON.stringify({ model_id: model, project_id: selectedProject }),
      });
      setChats(prev => [chat, ...prev]);
      setActiveChat(chat);
      chatId = chat.id;
    }

    setMessages(prev => [...prev, { role: 'user', content: text, enhanced, created_at: new Date().toISOString() }]);
    setInput('');
    setEnhancement(null);
    setStreaming(true);
    setStreamText('');
    setThinkingText('');

    streamSend(
      chatId, text, model, enhanced, thinkingMode, fastMode,
      (delta) => setStreamText(prev => prev + delta),
      (thinking) => setThinkingText(prev => prev + thinking),
      (usage) => {
        setStreamText('');
        setThinkingText('');
        setStreaming(false);
        api(`/chat/${chatId}`).then(data => {
          setMessages(data.messages);
          setChats(prev => prev.map(c => c.id === chatId ? { ...c, title: data.chat.title, updated_at: data.chat.updated_at } : c));
        });
      },
      (err) => {
        setStreamText(prev => prev + `\n\n⚠️ Error: ${err}`);
        setStreaming(false);
      }
    );
  }, [activeChat, model, streaming, selectedProject, thinkingMode, fastMode]);

  const handleEnhance = async () => {
    if (!input.trim()) return;
    setEnhancing(true);
    try {
      const result = await api('/enhance', {
        method: 'POST',
        body: JSON.stringify({ prompt: input, project_id: selectedProject }),
      });
      setEnhancement(result);
    } catch (e) {
      console.error('Enhancement failed:', e);
    }
    setEnhancing(false);
  };

  const handleSubmit = () => {
    if (enhanceMode && !enhancement) {
      handleEnhance();
    } else {
      send(input);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const createProject = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const project = await api('/project', {
      method: 'POST',
      body: JSON.stringify({ name: form.get('name'), goal: form.get('goal') }),
    });
    setProjects(prev => [project, ...prev]);
    setShowProjectForm(false);
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── Sidebar ── */}
      <div className="w-64 flex-shrink-0 flex flex-col border-r" style={{ background: 'var(--color-panel)', borderColor: 'var(--color-border)' }}>
        <div className="p-3 border-b flex items-center justify-between" style={{ borderColor: 'var(--color-border)' }}>
          <span className="font-semibold text-sm tracking-wider" style={{ color: 'var(--color-accent)' }}>NEXUS</span>
          {health && (
            <span className="w-2 h-2 rounded-full" style={{ background: health.status === 'healthy' ? 'var(--color-success)' : 'var(--color-danger)' }} title={health.status} />
          )}
        </div>

        <div className="flex border-b text-xs" style={{ borderColor: 'var(--color-border)' }}>
          {['chats', 'projects'].map(tab => (
            <button key={tab} onClick={() => setSidebarTab(tab)}
              className="flex-1 py-2 capitalize transition-colors"
              style={{ color: sidebarTab === tab ? 'var(--color-accent)' : 'var(--color-text-dim)', borderBottom: sidebarTab === tab ? '2px solid var(--color-accent)' : '2px solid transparent' }}>
              {tab}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto">
          {sidebarTab === 'chats' && (
            <>
              <button onClick={createChat} className="w-full p-3 text-left text-sm border-b transition-colors hover:opacity-80"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-accent)' }}>
                + New Chat
              </button>
              {chats.map(chat => (
                <div key={chat.id} onClick={() => selectChat(chat)}
                  className="p-3 border-b cursor-pointer flex items-center justify-between group transition-colors"
                  style={{
                    borderColor: 'var(--color-border)',
                    background: activeChat?.id === chat.id ? 'var(--color-accent-dim)' : 'transparent',
                  }}>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm truncate" style={{ color: 'var(--color-text)' }}>{chat.title}</div>
                    {chat.project_name && (
                      <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-dim)' }}>{chat.project_name}</div>
                    )}
                  </div>
                  <button onClick={(e) => deleteChat(e, chat.id)}
                    className="opacity-0 group-hover:opacity-100 ml-2 text-xs transition-opacity"
                    style={{ color: 'var(--color-danger)' }}>✕</button>
                </div>
              ))}
            </>
          )}

          {sidebarTab === 'projects' && (
            <>
              <button onClick={() => setShowProjectForm(f => !f)} className="w-full p-3 text-left text-sm border-b transition-colors hover:opacity-80"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-accent)' }}>
                + New Project
              </button>
              {showProjectForm && (
                <form onSubmit={createProject} className="p-3 border-b" style={{ borderColor: 'var(--color-border)' }}>
                  <input name="name" placeholder="Project name" required
                    className="w-full p-2 mb-2 rounded text-sm" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }} />
                  <textarea name="goal" placeholder="Goal (optional)" rows={2}
                    className="w-full p-2 mb-2 rounded text-sm resize-none" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }} />
                  <button type="submit" className="w-full p-2 rounded text-sm font-medium"
                    style={{ background: 'var(--color-accent)', color: '#fff' }}>Create</button>
                </form>
              )}
              {projects.map(p => (
                <div key={p.id} onClick={() => setSelectedProject(selectedProject === p.id ? null : p.id)}
                  className="p-3 border-b cursor-pointer transition-colors"
                  style={{
                    borderColor: 'var(--color-border)',
                    background: selectedProject === p.id ? 'var(--color-accent-dim)' : 'transparent',
                  }}>
                  <div className="text-sm" style={{ color: 'var(--color-text)' }}>{p.name}</div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-dim)' }}>
                    {p.status} · {p.chat_count || 0} chats
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {selectedProject && (
          <div className="p-2 border-t text-xs flex items-center justify-between" style={{ borderColor: 'var(--color-border)', background: 'var(--color-accent-dim)' }}>
            <span style={{ color: 'var(--color-accent)' }}>📁 {projects.find(p => p.id === selectedProject)?.name}</span>
            <button onClick={() => setSelectedProject(null)} style={{ color: 'var(--color-text-dim)' }}>✕</button>
          </div>
        )}
      </div>

      {/* ── Main Area ── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="px-4 py-2 border-b flex items-center justify-between" style={{ background: 'var(--color-panel)', borderColor: 'var(--color-border)' }}>
          <div className="text-sm" style={{ color: 'var(--color-text-dim)' }}>
            {activeChat?.title || 'Select or create a chat'}
          </div>
          <div className="flex items-center gap-2">
            {/* Model selector — driven by API */}
            <select value={model} onChange={e => {
              setModel(e.target.value);
              if (activeChat) api(`/chat/${activeChat.id}`, { method: 'PATCH', body: JSON.stringify({ model_id: e.target.value }) });
            }}
              className="text-xs px-2 py-1 rounded" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}>
              {models.map(m => (
                <option key={m.id} value={m.id}>
                  {m.label} — {m.tier === 'apex' ? '🔥' : m.tier === 'fast' ? '⚡' : m.tier === 'legacy' ? '📦' : '●'} ${Number(m.input_price)}/${Number(m.output_price)}
                </option>
              ))}
            </select>

            {/* Capability toggles — only shown when the selected model supports them */}
            {currentModel?.supports_thinking && (
              <button onClick={() => setThinkingMode(!thinkingMode)}
                className="text-xs px-2 py-1 rounded transition-colors"
                title="Extended thinking"
                style={{
                  background: thinkingMode ? '#7c3aed' : 'var(--color-bg)',
                  border: '1px solid var(--color-border)',
                  color: thinkingMode ? '#fff' : 'var(--color-text-dim)',
                }}>🧠</button>
            )}

            {currentModel?.supports_fast && (
              <button onClick={() => setFastMode(!fastMode)}
                className="text-xs px-2 py-1 rounded transition-colors"
                title="Fast mode (~2.5x speed)"
                style={{
                  background: fastMode ? '#f59e0b' : 'var(--color-bg)',
                  border: '1px solid var(--color-border)',
                  color: fastMode ? '#fff' : 'var(--color-text-dim)',
                }}>⚡</button>
            )}

            {/* Enhance toggle */}
            <button onClick={() => { setEnhanceMode(!enhanceMode); setEnhancement(null); }}
              className="text-xs px-2 py-1 rounded transition-colors"
              title="Prompt enhancement"
              style={{
                background: enhanceMode ? 'var(--color-accent)' : 'var(--color-bg)',
                border: '1px solid var(--color-border)',
                color: enhanceMode ? '#fff' : 'var(--color-text-dim)',
              }}>
              {enhanceMode ? '✦ Enhanced' : '◇ Direct'}
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && !streaming && (
            <div className="flex items-center justify-center h-full">
              <div className="text-center" style={{ color: 'var(--color-text-dim)' }}>
                <div className="text-2xl mb-2" style={{ color: 'var(--color-accent)' }}>NEXUS</div>
                <div className="text-sm">Start a conversation{selectedProject ? ` within ${projects.find(p => p.id === selectedProject)?.name}` : ''}</div>
                {currentModel && (
                  <div className="text-xs mt-2" style={{ color: 'var(--color-text-dim)' }}>
                    {currentModel.label} · {currentModel.notes}
                  </div>
                )}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={msg.id || i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className="max-w-[80%] rounded-lg px-4 py-3"
                style={{
                  background: msg.role === 'user' ? 'var(--color-accent-dim)' : 'var(--color-panel)',
                  border: '1px solid var(--color-border)',
                }}>
                {msg.role === 'assistant' ? (
                  <div className="prose text-sm" style={{ color: 'var(--color-text)' }}>
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
                  </div>
                ) : (
                  <div className="text-sm whitespace-pre-wrap" style={{ color: 'var(--color-text)' }}>{msg.content}</div>
                )}
                {msg.role === 'assistant' && msg.cost_usd != null && (
                  <div className="mt-2 pt-1 border-t text-xs flex gap-3" style={{ borderColor: 'var(--color-border)', color: 'var(--color-text-dim)' }}>
                    <span>{models.find(m => m.id === msg.model_used)?.label || msg.model_used}</span>
                    <span>{msg.tokens_in}→{msg.tokens_out} tok</span>
                    <span>${Number(msg.cost_usd).toFixed(4)}</span>
                    <span>{(msg.duration_ms / 1000).toFixed(1)}s</span>
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Thinking indicator */}
          {streaming && thinkingText && (
            <div className="flex justify-start">
              <details className="max-w-[80%] rounded-lg px-4 py-2" style={{ background: '#1a1035', border: '1px solid #7c3aed40' }}>
                <summary className="text-xs cursor-pointer" style={{ color: '#7c3aed' }}>🧠 Thinking...</summary>
                <div className="mt-2 text-xs whitespace-pre-wrap" style={{ color: 'var(--color-text-dim)' }}>{thinkingText}</div>
              </details>
            </div>
          )}

          {/* Streaming response */}
          {streaming && streamText && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-lg px-4 py-3" style={{ background: 'var(--color-panel)', border: '1px solid var(--color-border)' }}>
                <div className="prose text-sm" style={{ color: 'var(--color-text)' }}>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{streamText}</ReactMarkdown>
                </div>
              </div>
            </div>
          )}

          {streaming && !streamText && !thinkingText && (
            <div className="flex justify-start">
              <div className="rounded-lg px-4 py-3" style={{ background: 'var(--color-panel)', border: '1px solid var(--color-border)', color: 'var(--color-text-dim)' }}>
                <span className="animate-pulse">●●●</span>
              </div>
            </div>
          )}

          <div ref={messagesEnd} />
        </div>

        {/* Enhancement pre-flight panel */}
        {enhancement && (
          <div className="mx-4 mb-2 rounded-lg p-3" style={{ background: 'var(--color-panel)', border: '1px solid var(--color-accent)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium" style={{ color: 'var(--color-accent)' }}>✦ Enhancement Preview</span>
              <span className="text-xs" style={{ color: 'var(--color-text-dim)' }}>
                {enhancement.duration_ms}ms · ${Number(enhancement.cost_usd).toFixed(4)}
              </span>
            </div>
            <div className="text-xs mb-2 p-2 rounded" style={{ background: 'var(--color-bg)', color: 'var(--color-text-dim)', border: '1px solid var(--color-border)' }}>
              <div className="font-medium mb-1">Original:</div>
              <div>{enhancement.original}</div>
            </div>
            <div className="text-sm mb-3 p-2 rounded" style={{ background: 'var(--color-bg)', color: 'var(--color-text)', border: '1px solid var(--color-accent)' }}>
              <div className="font-medium mb-1 text-xs" style={{ color: 'var(--color-accent)' }}>Enhanced:</div>
              <div className="whitespace-pre-wrap">{enhancement.enhanced}</div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { send(enhancement.enhanced, true); }}
                className="px-3 py-1.5 rounded text-xs font-medium" style={{ background: 'var(--color-accent)', color: '#fff' }}>
                Send Enhanced
              </button>
              <button onClick={() => { send(enhancement.original); }}
                className="px-3 py-1.5 rounded text-xs" style={{ border: '1px solid var(--color-border)', color: 'var(--color-text)' }}>
                Send Original
              </button>
              <button onClick={() => { setInput(enhancement.enhanced); setEnhancement(null); }}
                className="px-3 py-1.5 rounded text-xs" style={{ border: '1px solid var(--color-border)', color: 'var(--color-text-dim)' }}>
                Edit
              </button>
              <button onClick={() => setEnhancement(null)}
                className="px-3 py-1.5 rounded text-xs" style={{ color: 'var(--color-danger)' }}>
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Input bar */}
        <div className="p-3 border-t" style={{ background: 'var(--color-panel)', borderColor: 'var(--color-border)' }}>
          {/* Active mode indicators */}
          {(thinkingMode || fastMode || enhanceMode) && (
            <div className="flex gap-2 mb-2 text-xs">
              {thinkingMode && <span className="px-2 py-0.5 rounded" style={{ background: '#7c3aed30', color: '#7c3aed' }}>🧠 Thinking</span>}
              {fastMode && <span className="px-2 py-0.5 rounded" style={{ background: '#f59e0b30', color: '#f59e0b' }}>⚡ Fast</span>}
              {enhanceMode && <span className="px-2 py-0.5 rounded" style={{ background: 'var(--color-accent-dim)', color: 'var(--color-accent)' }}>✦ Enhance</span>}
            </div>
          )}
          <div className="flex gap-2 items-end">
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={enhanceMode ? 'Type to enhance before sending...' : 'Type a message...'}
              rows={1}
              disabled={streaming}
              className="flex-1 resize-none p-3 rounded-lg text-sm"
              style={{
                background: 'var(--color-bg)',
                border: `1px solid ${enhanceMode ? 'var(--color-accent)' : 'var(--color-border)'}`,
                color: 'var(--color-text)',
                minHeight: '44px',
                maxHeight: '200px',
              }}
              onInput={e => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px'; }}
            />
            <button onClick={handleSubmit}
              disabled={!input.trim() || streaming}
              className="px-4 py-3 rounded-lg text-sm font-medium transition-opacity disabled:opacity-30"
              style={{ background: 'var(--color-accent)', color: '#fff' }}>
              {enhancing ? '...' : enhanceMode && !enhancement ? '✦' : '→'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
