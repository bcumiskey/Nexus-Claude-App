import { getDb } from '@/lib/db';
import { testConnection as testAnthropic } from '@/lib/anthropic';

export async function GET() {
  const sql = getDb();

  const [db, api] = await Promise.all([
    sql`SELECT 
      (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public') as tables,
      (SELECT COUNT(*) FROM models WHERE is_active = TRUE) as active_models`
      .then(r => ({ ok: true, tables: Number(r[0].tables), active_models: Number(r[0].active_models) }))
      .catch(e => ({ ok: false, error: e.message })),
    testAnthropic(),
  ]);

  const healthy = db.ok && api.ok && db.active_models > 0;
  return Response.json(
    { status: healthy ? 'healthy' : 'degraded', checks: { database: db, anthropic: api } },
    { status: healthy ? 200 : 503 }
  );
}
