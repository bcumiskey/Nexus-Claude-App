import { getDb } from '@/lib/db';

// Get active models for the frontend
export async function GET() {
  const sql = getDb();
  const models = await sql`
    SELECT id, label, tier, input_price, output_price, max_output, context_window,
           supports_thinking, supports_adaptive, supports_fast, supports_vision,
           supports_1m_ctx, is_default, is_enhancement, notes
    FROM models
    WHERE is_active = TRUE
    ORDER BY sort_order ASC
  `;
  return Response.json(models);
}

// Add or update a model (for when Anthropic ships something new)
export async function PUT(req) {
  const body = await req.json();
  const sql = getDb();

  // If setting this as default, unset the current default first
  if (body.is_default) {
    await sql`UPDATE models SET is_default = FALSE WHERE is_default = TRUE`;
  }
  if (body.is_enhancement) {
    await sql`UPDATE models SET is_enhancement = FALSE WHERE is_enhancement = TRUE`;
  }

  const [model] = await sql`
    INSERT INTO models (
      id, label, tier, input_price, output_price, max_output, context_window,
      supports_thinking, supports_adaptive, supports_fast, supports_vision,
      supports_1m_ctx, is_default, is_enhancement, is_active, sort_order, notes
    ) VALUES (
      ${body.id}, ${body.label}, ${body.tier || 'standard'},
      ${body.input_price}, ${body.output_price},
      ${body.max_output || 64000}, ${body.context_window || 200000},
      ${body.supports_thinking ?? false}, ${body.supports_adaptive ?? false},
      ${body.supports_fast ?? false}, ${body.supports_vision ?? true},
      ${body.supports_1m_ctx ?? false}, ${body.is_default ?? false},
      ${body.is_enhancement ?? false}, ${body.is_active ?? true},
      ${body.sort_order ?? 50}, ${body.notes || null}
    )
    ON CONFLICT (id) DO UPDATE SET
      label = EXCLUDED.label,
      tier = EXCLUDED.tier,
      input_price = EXCLUDED.input_price,
      output_price = EXCLUDED.output_price,
      max_output = EXCLUDED.max_output,
      context_window = EXCLUDED.context_window,
      supports_thinking = EXCLUDED.supports_thinking,
      supports_adaptive = EXCLUDED.supports_adaptive,
      supports_fast = EXCLUDED.supports_fast,
      supports_vision = EXCLUDED.supports_vision,
      supports_1m_ctx = EXCLUDED.supports_1m_ctx,
      is_default = EXCLUDED.is_default,
      is_enhancement = EXCLUDED.is_enhancement,
      is_active = EXCLUDED.is_active,
      sort_order = EXCLUDED.sort_order,
      notes = EXCLUDED.notes,
      updated_at = NOW()
    RETURNING *
  `;

  return Response.json(model);
}
