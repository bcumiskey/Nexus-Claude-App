import { getDb } from '@/lib/db';

// List projects
export async function GET() {
  const sql = getDb();
  const projects = await sql`
    SELECT p.*,
      (SELECT COUNT(*) FROM chats WHERE project_id = p.id) as chat_count
    FROM projects p
    ORDER BY p.updated_at DESC
  `;
  return Response.json(projects);
}

// Create project
export async function POST(req) {
  const { name, goal, status = 'active' } = await req.json();
  const sql = getDb();

  const [project] = await sql`
    INSERT INTO projects (name, goal, status) 
    VALUES (${name}, ${goal || null}, ${status})
    RETURNING *
  `;

  // Create initial empty context
  await sql`
    INSERT INTO project_context (project_id, context_json, compressed_text, version)
    VALUES (${project.id}, ${JSON.stringify({ decisions: [], discoveries: [], constraints: [] })}, ${goal || ''}, 1)
  `;

  return Response.json(project, { status: 201 });
}
