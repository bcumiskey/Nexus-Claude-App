import { getDb } from '@/lib/db';

// Get project with latest context
export async function GET(req, { params }) {
  const { id } = await params;
  const sql = getDb();

  const [project] = await sql`SELECT * FROM projects WHERE id = ${id}`;
  if (!project) return Response.json({ error: 'Not found' }, { status: 404 });

  const [context] = await sql`
    SELECT * FROM project_context WHERE project_id = ${id} ORDER BY version DESC LIMIT 1
  `;

  return Response.json({
    ...project,
    context: context ? JSON.parse(JSON.stringify(context.context_json)) : null,
    context_version: context?.version || 0,
    compressed_text: context?.compressed_text || '',
  });
}

// Update project or push new context version
export async function PATCH(req, { params }) {
  const { id } = await params;
  const body = await req.json();
  const sql = getDb();

  // If updating context, create a new version
  if (body.context_json || body.compressed_text) {
    const [latest] = await sql`
      SELECT version FROM project_context WHERE project_id = ${id} ORDER BY version DESC LIMIT 1
    `;
    const nextVersion = (latest?.version || 0) + 1;

    await sql`
      INSERT INTO project_context (project_id, context_json, compressed_text, version)
      VALUES (${id}, ${JSON.stringify(body.context_json || {})}, ${body.compressed_text || ''}, ${nextVersion})
    `;
  }

  // Update project fields if provided
  if (body.name || body.goal || body.status) {
    await sql`
      UPDATE projects SET
        name = COALESCE(${body.name ?? null}, name),
        goal = COALESCE(${body.goal ?? null}, goal),
        status = COALESCE(${body.status ?? null}, status),
        updated_at = NOW()
      WHERE id = ${id}
    `;
  }

  // Return updated project
  const [project] = await sql`SELECT * FROM projects WHERE id = ${id}`;
  return Response.json(project);
}

// Delete project
export async function DELETE(req, { params }) {
  const { id } = await params;
  const sql = getDb();
  await sql`DELETE FROM projects WHERE id = ${id}`;
  return Response.json({ deleted: true });
}
