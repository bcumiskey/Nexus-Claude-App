import { getDb } from '@/lib/db';
import { complete } from '@/lib/anthropic';
import { getEnhancementModelId } from '@/lib/models';

const ENHANCE_SYSTEM = `You are a prompt optimization engine. Rewrite the user's request to be maximally effective for a Claude model.
- Preserve the original intent exactly
- Add specificity where the original is vague
- Add output format instructions if none exist
- Add relevant constraints or edge case reminders
- If code: specify language, style, documentation expectations
- If analysis: specify dimensions to evaluate
- Do NOT add fluff or pleasantries
- Return ONLY the enhanced prompt, no explanation`;

export async function POST(req) {
  const { prompt, project_id } = await req.json();
  if (!prompt) return Response.json({ error: 'prompt is required' }, { status: 400 });

  let system = ENHANCE_SYSTEM;
  if (project_id) {
    try {
      const sql = getDb();
      const [ctx] = await sql`
        SELECT compressed_text FROM project_context 
        WHERE project_id = ${project_id} ORDER BY version DESC LIMIT 1
      `;
      if (ctx?.compressed_text) {
        system += `\n\nACTIVE PROJECT CONTEXT:\n${ctx.compressed_text}`;
      }
    } catch (e) {
      console.warn('Context lookup for enhancement failed:', e.message);
    }
  }

  const model = await getEnhancementModelId();

  try {
    const result = await complete({
      model,
      systemPrompt: system,
      messages: [{ role: 'user', content: prompt }],
      maxTokens: 2048,
    });

    return Response.json({
      original: prompt,
      enhanced: result.content,
      model: result.model,
      tokens_in: result.tokens_in,
      tokens_out: result.tokens_out,
      cost_usd: result.cost_usd,
      duration_ms: result.duration_ms,
    });
  } catch (err) {
    return Response.json({ error: 'Enhancement failed', detail: err.message }, { status: 500 });
  }
}
