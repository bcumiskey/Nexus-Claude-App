import { getDb } from '@/lib/db';
import { getDefaultModelId } from '@/lib/models';

// List all chats
export async function GET() {
  const sql = getDb();
  const chats = await sql`
    SELECT c.*, p.name as project_name,
      (SELECT COUNT(*) FROM messages WHERE chat_id = c.id) as message_count
    FROM chats c
    LEFT JOIN projects p ON c.project_id = p.id
    ORDER BY c.updated_at DESC
  `;
  return Response.json(chats);
}

// Create new chat
export async function POST(req) {
  const { title = 'New Chat', model_id, project_id } = await req.json();
  const model = model_id || await getDefaultModelId();
  const sql = getDb();

  const [chat] = await sql`
    INSERT INTO chats (title, model_id, project_id)
    VALUES (${title}, ${model}, ${project_id || null})
    RETURNING *
  `;
  return Response.json(chat, { status: 201 });
}
