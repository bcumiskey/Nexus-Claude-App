import { getDb } from '@/lib/db';

// Get chat with messages
export async function GET(req, { params }) {
  const { id } = await params;
  const sql = getDb();

  const [chat] = await sql`SELECT * FROM chats WHERE id = ${id}`;
  if (!chat) return Response.json({ error: 'Chat not found' }, { status: 404 });

  const messages = await sql`
    SELECT id, role, content, model_used, tokens_in, tokens_out, cost_usd, duration_ms, enhanced, created_at
    FROM messages WHERE chat_id = ${id} ORDER BY created_at ASC
  `;

  return Response.json({ chat, messages });
}

// Update chat
export async function PATCH(req, { params }) {
  const { id } = await params;
  const body = await req.json();
  const sql = getDb();

  const [chat] = await sql`
    UPDATE chats SET
      title = COALESCE(${body.title ?? null}, title),
      model_id = COALESCE(${body.model_id ?? null}, model_id),
      project_id = COALESCE(${body.project_id ?? null}, project_id),
      updated_at = NOW()
    WHERE id = ${id}
    RETURNING *
  `;
  return Response.json(chat);
}

// Delete chat
export async function DELETE(req, { params }) {
  const { id } = await params;
  const sql = getDb();
  await sql`DELETE FROM chats WHERE id = ${id}`;
  return Response.json({ deleted: true });
}
