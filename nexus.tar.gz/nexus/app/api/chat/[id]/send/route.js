import { getDb } from '@/lib/db';
import { streamChat, complete } from '@/lib/anthropic';
import { getDefaultModelId, getEnhancementModelId } from '@/lib/models';

export async function POST(req, { params }) {
  const { id: chatId } = await params;
  const { content, model_id, enhanced = false, thinking = false, fast = false } = await req.json();

  if (!content) {
    return Response.json({ error: 'content is required' }, { status: 400 });
  }

  const sql = getDb();

  // Get chat
  const [chat] = await sql`SELECT * FROM chats WHERE id = ${chatId}`;
  if (!chat) return Response.json({ error: 'Chat not found' }, { status: 404 });

  const model = model_id || chat.model_id;

  // Save user message
  await sql`
    INSERT INTO messages (chat_id, role, content, enhanced)
    VALUES (${chatId}, 'user', ${content}, ${enhanced})
  `;

  // Load conversation history
  const history = await sql`
    SELECT role, content FROM messages 
    WHERE chat_id = ${chatId} ORDER BY created_at ASC
  `;
  const messages = history.map(m => ({ role: m.role, content: m.content }));

  // Build system prompt with optional project context
  let systemPrompt = 'You are Claude, an AI assistant. Be helpful, direct, and concise.';
  if (chat.project_id) {
    try {
      const [ctx] = await sql`
        SELECT compressed_text FROM project_context 
        WHERE project_id = ${chat.project_id} 
        ORDER BY version DESC LIMIT 1
      `;
      if (ctx?.compressed_text) {
        systemPrompt += `\n\n## Active Project Context\n${ctx.compressed_text}`;
      }
    } catch (e) {
      console.warn('Context injection failed:', e.message);
    }
  }

  // Stream the response
  const { stream, usagePromise } = streamChat({ model, messages, systemPrompt, thinking, fast });

  // Fire-and-forget: save assistant message + update chat when stream completes
  usagePromise.then(async (meta) => {
    if (!meta) return;
    try {
      await sql`
        INSERT INTO messages (chat_id, role, content, model_used, tokens_in, tokens_out, cost_usd, duration_ms)
        VALUES (${chatId}, 'assistant', ${meta.content}, ${model}, ${meta.tokens_in}, ${meta.tokens_out}, ${meta.cost_usd}, ${meta.duration_ms})
      `;
      await sql`UPDATE chats SET updated_at = NOW() WHERE id = ${chatId}`;

      // Auto-title from first message
      if (chat.title === 'New Chat' && history.length <= 1) {
        generateTitle(chatId, content).catch(() => {});
      }
    } catch (e) {
      console.error('Post-stream save failed:', e.message);
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    },
  });
}

async function generateTitle(chatId, userMessage) {
  const enhModel = await getEnhancementModelId();
  const result = await complete({
    model: enhModel,
    maxTokens: 30,
    messages: [{
      role: 'user',
      content: `Generate a short title (max 6 words) for a conversation starting with this message. Reply with ONLY the title, no quotes:\n\n${userMessage.slice(0, 500)}`,
    }],
  });
  const title = result.content.trim().replace(/^["']|["']$/g, '').slice(0, 100);
  if (title) {
    const sql = getDb();
    await sql`UPDATE chats SET title = ${title} WHERE id = ${chatId}`;
  }
}
