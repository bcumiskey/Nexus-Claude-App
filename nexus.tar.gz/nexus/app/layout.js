import './globals.css';

export const metadata = {
  title: 'Nexus',
  description: 'AI Operations Platform',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased">{children}</body>
    </html>
  );
}
